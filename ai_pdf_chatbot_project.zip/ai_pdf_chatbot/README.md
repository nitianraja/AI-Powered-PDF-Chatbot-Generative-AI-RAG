# AI-Powered PDF Chatbot

A beginner-friendly Retrieval-Augmented Generation (RAG) application. Upload a PDF and ask questions about its content. The app retrieves relevant passages with vector search and asks Google Gemini to answer using those passages.

## Features

- Upload and read text-based PDF files
- Split document text into overlapping chunks
- Create local embeddings with Sentence Transformers
- Store/search embeddings using FAISS
- Generate grounded answers with the Gemini API
- Show retrieved passages and their PDF page numbers
- Keep chat history during the current Streamlit session

## Tech stack

Python, Streamlit, Google Gemini API, Sentence Transformers, FAISS, PyPDF, NumPy.

## Requirements

- Python 3.10–3.12 recommended
- Internet connection for installing packages, downloading the embedding model, and calling Gemini
- A Gemini API key from Google AI Studio

## Run locally

### 1. Unzip and enter the project folder

```bash
cd ai_pdf_chatbot
```

### 2. Create and activate a virtual environment

Windows PowerShell:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If `faiss-cpu` fails to install on your platform, use a supported Python version (3.10–3.12) and a compatible 64-bit environment.

### 4. Add your Gemini API key

Copy `.env.example` to `.env` and replace the placeholder:

```env
GEMINI_API_KEY=your_actual_key
```

Alternatively, paste the key into the app's sidebar when it runs. Never commit `.env` or share your API key.

### 5. Start the app

```bash
streamlit run app.py
```

Streamlit will print a local URL, usually `http://localhost:8501`.

## How the RAG pipeline works

1. **Ingestion:** PyPDF extracts selectable text and page numbers.
2. **Chunking:** Text is split into overlapping chunks to preserve context.
3. **Embedding:** Sentence Transformers converts each chunk into a vector.
4. **Indexing:** FAISS stores vectors for efficient similarity search.
5. **Retrieval:** The user's question is embedded and the closest passages are selected.
6. **Generation:** Gemini receives the question and retrieved passages and writes an answer grounded in that context.

## Project structure

```text
ai_pdf_chatbot/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── data/
```

## Important limitations

- Scanned/image-only PDFs are not supported because OCR is not included.
- Answers depend on the quality of extracted PDF text and retrieved passages.
- Similarity search can miss relevant passages; this is a learning project, not a guaranteed factual system.
- Do not upload private, confidential, or sensitive documents.
- Gemini API usage may be subject to quotas, availability, and pricing. Check the current Google AI Studio terms.

## Ideas to improve it

- Add OCR for scanned PDFs.
- Support multiple PDFs and document collections.
- Add conversation-aware follow-up questions.
- Add source highlighting and downloadable chat history.
- Add authentication and deployment.

## Resume description

**AI-Powered PDF Chatbot | Generative AI / RAG**

- Built a PDF question-answering application using Retrieval-Augmented Generation (RAG).
- Implemented PDF text extraction, overlapping text chunking, and semantic embeddings using Sentence Transformers.
- Used FAISS vector similarity search to retrieve relevant document passages.
- Integrated Google Gemini API to generate context-grounded answers and display source page references.
- Developed an interactive interface using Streamlit.

**Technologies:** Python, Streamlit, Google Gemini API, RAG, Sentence Transformers, FAISS, PyPDF.
