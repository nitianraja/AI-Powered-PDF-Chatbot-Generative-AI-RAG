import os
import tempfile
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
from google import genai
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

load_dotenv()

st.set_page_config(page_title="AI PDF Chatbot", page_icon="📄", layout="wide")
st.title("📄 AI-Powered PDF Chatbot")
st.caption("Upload a PDF, ask questions, and get answers grounded in the document.")

MODEL_NAME = "gemini-2.5-flash"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
CHUNK_SIZE = 900
CHUNK_OVERLAP = 150
TOP_K = 4

@st.cache_resource
def load_embedding_model():
    return SentenceTransformer(EMBEDDING_MODEL)

def extract_pages(uploaded_file):
    reader = PdfReader(uploaded_file)
    pages = []
    for page_number, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        if text.strip():
            pages.append((page_number, text))
    return pages

def split_text(text, page_number):
    words = text.split()
    chunks = []
    start = 0
    while start < len(words):
        end = min(start + CHUNK_SIZE, len(words))
        chunk = " ".join(words[start:end]).strip()
        if chunk:
            chunks.append({"text": chunk, "page": page_number})
        if end == len(words):
            break
        start = max(end - CHUNK_OVERLAP, start + 1)
    return chunks

def build_index(chunks, embedder):
    texts = [item["text"] for item in chunks]
    vectors = embedder.encode(texts, convert_to_numpy=True, normalize_embeddings=True)
    vectors = np.asarray(vectors, dtype="float32")
    index = faiss.IndexFlatIP(vectors.shape[1])
    index.add(vectors)
    return index

def retrieve(question, chunks, index, embedder, top_k=TOP_K):
    query_vector = embedder.encode(
        [question], convert_to_numpy=True, normalize_embeddings=True
    ).astype("float32")
    k = min(top_k, len(chunks))
    scores, indices = index.search(query_vector, k)
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx >= 0:
            item = chunks[int(idx)].copy()
            item["score"] = float(score)
            results.append(item)
    return results

def generate_answer(question, contexts, api_key):
    client = genai.Client(api_key=api_key)
    context_text = "\n\n".join(
        f"[Source: page {item['page']}]\n{item['text']}" for item in contexts
    )
    prompt = f"""You are a helpful assistant answering questions about an uploaded PDF.
Use ONLY the supplied context to answer. If the answer is not present, clearly say
"I couldn't find that information in the uploaded document."
Do not invent facts. Keep the answer clear and concise. Mention relevant page numbers.

DOCUMENT CONTEXT:
{context_text}

USER QUESTION:
{question}
"""
    response = client.models.generate_content(model=MODEL_NAME, contents=prompt)
    return response.text or "I couldn't generate a response. Please try again."

with st.sidebar:
    st.header("⚙️ Setup")
    api_key_input = st.text_input(
        "Gemini API key",
        value=os.getenv("GEMINI_API_KEY", ""),
        type="password",
        help="Create a key in Google AI Studio and paste it here, or add it to .env.",
    )
    st.markdown("---")
    st.markdown("**How it works**")
    st.write("PDF → text extraction → chunks → embeddings → FAISS search → Gemini answer")
    st.caption("Your PDF is processed in this app session. Do not upload confidential documents.")

uploaded_file = st.file_uploader("Choose a PDF document", type=["pdf"])

if uploaded_file:
    if not api_key_input:
        st.warning("Add your Gemini API key in the sidebar to start chatting.")
        st.stop()

    file_signature = f"{uploaded_file.name}-{uploaded_file.size}"
    if st.session_state.get("file_signature") != file_signature:
        with st.spinner("Reading PDF and building the search index..."):
            try:
                pages = extract_pages(uploaded_file)
                chunks = []
                for page_number, page_text in pages:
                    chunks.extend(split_text(page_text, page_number))
                if not chunks:
                    st.error("No selectable text was found. This PDF may be scanned; OCR is not included.")
                    st.stop()
                embedder = load_embedding_model()
                index = build_index(chunks, embedder)
                st.session_state["chunks"] = chunks
                st.session_state["index"] = index
                st.session_state["embedder"] = embedder
                st.session_state["file_signature"] = file_signature
                st.session_state["messages"] = []
            except Exception as exc:
                st.error(f"Could not process this PDF: {exc}")
                st.stop()

    chunks = st.session_state["chunks"]
    st.success(f"Document ready: {len(chunks)} searchable text chunks.")
    for message in st.session_state.get("messages", []):
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    question = st.chat_input("Ask something about your PDF...")
    if question:
        st.session_state["messages"].append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            with st.spinner("Searching the document and generating an answer..."):
                try:
                    sources = retrieve(
                        question, chunks, st.session_state["index"],
                        st.session_state["embedder"]
                    )
                    answer = generate_answer(question, sources, api_key_input)
                    st.markdown(answer)
                    with st.expander("Retrieved document passages"):
                        for item in sources:
                            st.markdown(f"**Page {item['page']}** · similarity {item['score']:.3f}")
                            st.write(item["text"])
                    st.session_state["messages"].append(
                        {"role": "assistant", "content": answer}
                    )
                except Exception as exc:
                    st.error(f"Something went wrong: {exc}")
else:
    st.info("Upload a PDF above to begin.")
